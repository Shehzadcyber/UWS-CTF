#!/bin/bash

docker build -t uws-ctf-hackathon-2025-ctfd:latest .
